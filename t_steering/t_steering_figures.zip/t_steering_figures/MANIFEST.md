# t-steering — corner plots, tables, enrichment, gaps

Biased MCMC on a Potts/bmDCA model of the serine-protease family. Everything
here is *in silico*: sequence arrays, CSVs of observables and figures. All runs
are 1000 chains x 60,000 steps, read through the beta = 1 serine rescoring,
which is the only form in which runs sampled at different beta are comparable.

## The colour code — one hue per mutation set, used everywhere

| set | columns | colour | hex |
|---|---|---|---|
| `segment` | 79, the grafting window 165-243 | green | `#1baf7a` |
| `redsector` | 16, red sector ∩ segment | blue | `#2a78d6` |
| `coupling20` | 20, most coupled to the critic | orange | `#eb6834` |

These are slots 1-3 of the project's validated palette — the only three that
pass the all-pairs separation gate, which is what a scatter or corner plot
needs. Within a set, `t` is a **single-hue light-to-dark ramp**: an ordered
magnitude, never a category. So a pale green cloud and a dark green cloud are
two settings of one knob on one set, and green vs orange is two sets.

## Contents

```
corners/      s06_ladder_corner_<set>_beta<1|3>_5x5     6 figures
tables/       s05_ladder_table_<set>_beta<1|3>          6 tables
              s04_table                                 the 6 selected designs
enrichment/   s07_sectors_beta<1|3>                     red-sector enrichment
gaps/         s08_indels_beta<1|3>                      indels + gap abundance
*.csv                                                   the numbers behind each
```

Every figure is 300 dpi PNG plus vector PDF.

## What each one is

**corners/** — the `t` ladder as a 5x5 corner: `d_H`, `E_DCA`, CDE, `Q`, `P(S)`,
five rungs `t = 0, 0.5, 1, 2, 4` at `lambda = 300`. The `E_DCA`-CDE panel is the
decomposition of `Q = E - mu*CDE`: with `mu ~ 423` the two move together, and
89 % of the ladder's energy gain is cancelled in `Q`. Read `Q` alone and you
conclude the restraint barely touches quality; read both and you see that each
component moves by an order of magnitude more.

**tables/** — the same rungs as numbers, and the six selected designs with the
best value in each column bold. No row is "the winner": the four requirements
(short budget, wild-type-like `Q`, batch diversity, high `P(S)`) trade against
each other, and a single score would bury which one each run paid with.

**enrichment/** — red-sector enrichment, defined as
`(share of mutations in red) / (share of MUTABLE columns in red)`. The
denominator is the number of *mutable* columns, never the number of columns,
or a site restriction manufactures its own enrichment. `redsector` is drawn
dotted because its enrichment is identically 1 by construction — all 16 of its
mutable columns are red. Panel (b) uses the sector's own importance ranking,
which is not model-derived and so carries between models.

**gaps/** — how much of `d_H` is indels rather than substitutions, and whether
the gap pattern moves. All runs use `--allow-gap-moves`, so `d_H` counts both.

## Two things to read with care

**`beta = 3` is inside the frozen regime.** The study's factorial stops at
`beta = 1.5` because at `beta >= 2` a chain is frozen rather than settled. All
15 `beta = 3` runs pass the drift test on `E`, `Q`, `d` and `P(S)` *and* all 15
sit below 20 accepted moves per mutable site (2.8-5.1 on `segment`) — zero
motion is zero drift. `coupling20` at `beta = 3` has non-monotone `<d>` in `t`
(5.20, 5.04, **5.16**, 4.77, 4.17), and since `-d<d>/dt = Var(d) >= 0` is an
identity for any equilibrium ensemble, that rise is proof the rung is not an
equilibrium sample. Read `beta = 3` as an upper bound on quality, not as a
design protocol.

**No design reaches wild-type `Q`** at `beta = 1`; the grid sits 2.5-19.1 above
it. Against the natural family's own `sd(Q) = 28.0` that is 0.09-0.68 standard
deviations, so "similar to the wild type" is defined on the family's scale
rather than as `Q <= Q_WT`, which admitted nothing.
